import type { ModelCommand } from "./protocol";

export const localModelingInstructions = `When localModeling is true, use kind generated with a typed local Blender job for genuinely new shapes that benefit from custom meshes, extrusions, lathes or modifiers. Mix useful catalog, procedural and generated geometry; new-only still forbids catalog reuse. Reserve the entity first without geometry, optionally provide a procedural coarse preview, then send one refined generated job. Do not repeat the same Blender job for coarse and refined stages. Never supply the model metadata field: the trusted local executor creates it. Jobs use Y-up coordinates, radians for XYZ rotation, positive scale, and hex colors. Extrude profile points [x,y] along Z using depth; lathe profile points [radius,height] around Y. Primitive box/sphere/cylinder/cone have size/diameter 2 before scaling. Set collision platform only for a generated walkable platform; otherwise use none. Use bounded, low-complexity jobs. No Python, URLs or files. Preserve stable entity IDs on edits. Use set_material for a recolor without rebuilding the mesh.`;

export const browserModelingInstructions = `When browserModeling is true, use kind generated with a browser-manifold recipe shaped as {backend:"browser-manifold",recipe:{version:1,revision,output,nodes}} for genuinely new shapes. Prefer structured browser-manifold recipes; for an unusual shape that needs deterministic procedural construction, you may instead use {backend:"browser-procedural",source:{version:1,language:"quickjs",seed,code}} where code is a bounded expression returning one complete versioned recipe. The browser builder supports only centered box(size), sphere(radius, segments), cylinder(radius, depth, axis x/y/z), revolve(profile, segments), extrude(profile, depth), bounded closed triangle mesh(vertices, triangles), capped open tube(path, radius, segments), transform(input, position, rotation, scale), mirror(input, normal), linear-array(input, count, offset), instances(input, transforms), compose(inputs), twist(input, angle), taper(input, bottomScale, topScale), vary(input, seed, amplitude), and boolean union/subtract/intersect nodes. Deformations rebuild the solid through bounded mesh validation, so keep deformed inputs within 4096 vertices and 8192 triangles. Twist rotates each Y slice by angle*t about the input's vertical axis at its XZ center, with angle in radians within ±π/2 and unchanged Y extents. Taper linearly scales XZ from bottomScale at the bottom to topScale at the top, both within [0.25, 4], leaving Y unchanged. Vary scales slices radially about the XZ center with a seeded coherent profile: integer seed 0–1023 and amplitude in (0, 0.5]; identical recipe and seed reproduce identical geometry and different seeds produce a different silhouette. Mesh nodes use 4–4096 finite Y-up vertices within ±100 meters and 4–8192 triangles; they must form one connected, positively oriented closed shell with no duplicate, unused, degenerate, overlapping, or self-intersecting triangles. Mesh validation is bounded and fail-closed; use separate graph nodes for compound solids. Tube paths use 2–63 unique Float32-normalized Y-up points within ±100 meters, radius greater than 1e-4 and at most 50 meters, and 3–64 radial segments (default 16). Tubes are open polylines with flat caps; reject closed loops, repeated endpoints, variable radius, twist, and custom profiles. Reject ambiguous reversals, degenerate segments, self-overlap, and generated vertices outside ±100 meters. Mirror normals must be nonzero and define a plane through the origin. Compose, linear-array, and instances only combine separated solids: touching or overlapping copies are rejected; use boolean union when surfaces should merge. Linear arrays use 2–32 copies with a nonzero per-copy offset. Instances use 1–32 explicit positive-scale XYZ transforms. These operations bake copies into one geometry output; they do not provide scene parenting, separate entity IDs, or GPU instancing. Revolve profiles use [radius,height] points with nonnegative radius and a full 360-degree sweep around Y, preserving the explicit heights without automatic centering; segments default to 32 (maximum 64). Extrude profiles use [x,y] points along Z, centered from -depth/2 to +depth/2. Both profiles are simple closed polygons with 3–64 distinct points and implicit closing edges; do not repeat the first point, request holes, or request a partial sweep. Keep recipes within 64 nodes, depth 16, 64 expanded geometry leaves, segments 64, and the evaluator's 100,000-triangle and 8 MiB intermediate mesh limits; the baked GLB must stay within 2 MiB. Dimensions and positions are meters in a Y-up world; rotations are radians using XYZ order; scale is positive. Reserve the entity first without geometry, then send one refined browser job; do not send a coarse browser job. Never supply model metadata: the trusted browser builder creates it. Every node ID must be unique. recipe.output must exactly match an existing node ID; every node must be reachable from that output. Node IDs are separate from the scene entity ID. For one-node extrusion, use output:"mesh" and nodes:[{id:"mesh",kind:"extrude",profile:[[-1,-1],[1,-1],[0,1]],depth:1}]. Preserve editable recipe revisions and stable node/entity IDs on edits. Follow new-only rules. Do not pair this backend with Blender, and do not claim support for partial sweeps, external scripts, URLs, or external assets.`;

export function modelingInstructions(
  localModeling = false,
  browserModeling = false,
) {
  return [
    localModeling ? localModelingInstructions : "",
    browserModeling ? browserModelingInstructions : "",
  ]
    .filter(Boolean)
    .join(" ");
}

/** Model output may request construction, but cannot assert trusted artifact identity. */
export function assertModelingCommand(
  command: ModelCommand,
  available: boolean,
  browserAvailable = false,
) {
  if (
    command.type === "reserve_entity" &&
    command.entity.geometry?.kind === "generated"
  )
    throw Error(
      "Reserve the object first, then request its local model with set_geometry.",
    );
  if (command.type !== "set_geometry" || command.geometry.kind !== "generated")
    return;
  const browserBackend =
    "backend" in command.geometry.job &&
    (command.geometry.job.backend === "browser-manifold" ||
      command.geometry.job.backend === "browser-procedural");
  if (browserBackend) {
    if (!browserAvailable)
      throw Error(
        "Browser modeling is unavailable. Use a browser with Web Workers and WebAssembly support.",
      );
    if ("model" in command.geometry && command.geometry.model)
      throw Error(
        "Generated model identities must come from the browser builder.",
      );
    if (command.geometry.detail !== "refined")
      throw Error(
        "Browser modeling jobs must provide refined geometry; use a procedural preview first.",
      );
    return;
  }
  if (!available)
    throw Error(
      "This modeling job is unsupported. Request a browser-manifold recipe instead.",
    );
  if ("model" in command.geometry && command.geometry.model)
    throw Error("Generated model identities must come from the local builder.");
  if (command.geometry.detail !== "refined")
    throw Error(
      "Local Blender jobs must provide refined geometry; use a procedural preview first.",
    );
}
