# The daydream garden

An independent Orbsie world. No account, AI credentials, editor services, or API is required to play.

Run npm install and npm run dev, or serve this directory with any static HTTP server. Use WASD/arrow keys and Space to jump; touch controls are included.

The pinned, bundled runtime.js and runtime.css work directly. Runtime source is included under src. To rebuild from source: npm run build:source. Project content is project.json.

The Orbsie runtime is Apache-2.0 licensed. Original creator retains their project content rights.
